
import os
import json
import matplotlib.pyplot as plt
import seaborn as sns
from collections import defaultdict

BLOOM_DIR = "juliet_flowers/bloom_metadata"
OUTPUT = "juliet_flowers/cluster_report/mood_heatmap.png"

def build_mood_heatmap():
    mood_map = defaultdict(list)

    for fname in os.listdir(BLOOM_DIR):
        if fname.endswith(".json"):
            with open(os.path.join(BLOOM_DIR, fname), "r") as f:
                bloom = json.load(f)
                mood = bloom.get("mood", "undefined")
                entropy = bloom.get("entropy_score", 0.0)
                lineage = bloom.get("lineage_depth", 0)
                mood_map[mood].append((lineage, entropy))

    if not mood_map:
        print("[Heatmap] ❌ No bloom data found.")
        return

    # Build grid
    heat_data = {}
    for mood, entries in mood_map.items():
        mood_series = defaultdict(list)
        for lineage, entropy in entries:
            mood_series[lineage].append(entropy)
        # Average entropy by lineage for this mood
        for lineage, values in mood_series.items():
            heat_data[(mood, lineage)] = sum(values) / len(values)

    # Create mood × lineage matrix
    moods = sorted(set(k[0] for k in heat_data))
    lineages = sorted(set(k[1] for k in heat_data))
    matrix = [
        [heat_data.get((m, l), 0.0) for l in lineages]
        for m in moods
    ]

    plt.figure(figsize=(10, 6))
    sns.heatmap(matrix, annot=True, xticklabels=lineages, yticklabels=moods, cmap="coolwarm", cbar=True)
    plt.title("🧠 Mood-based Entropy Heatmap")
    plt.xlabel("Lineage Depth")
    plt.ylabel("Mood")
    plt.tight_layout()
    plt.savefig(OUTPUT)
    print(f"[Heatmap] ✅ Saved → {OUTPUT}")
