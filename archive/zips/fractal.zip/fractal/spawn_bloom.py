
import os, time
from datetime import datetime
from generate_julia_set import generate_julia_set
from nutrient_logger import log_nutrient_flow

last_bloom_time = {}

def mood_transition(seed_id, new_mood):
    mood_history = last_bloom_time.get(seed_id, {}).get('mood', 'calm')
    allowed_transitions = {
        'calm': ['reflective', 'curious'],
        'reflective': ['curious', 'calm'],
        'curious': ['anxious', 'reflective', 'calm'],
        'anxious': ['calm', 'reflective']
    }
    return new_mood if new_mood in allowed_transitions.get(mood_history, []) else mood_history

def spawn_juliet_bloom(seed_id, mood, lineage_depth, entropy, c_real, c_imag, zoom_level, bloom_factor):
    now = datetime.now()
    bloom_id = f"juliet_{now.strftime('%Y-%m-%dT%H-%M-%S')}"
    dir_path = f"juliet_flowers/{seed_id}/{mood}"
    os.makedirs(dir_path, exist_ok=True)
    
    if seed_id in last_bloom_time:
        elapsed = time.time() - last_bloom_time[seed_id]['timestamp']
        if elapsed < 5:  # 5 seconds cooldown
            print(f"[BloomThrottle] ⚠️ Throttling bloom for seed {seed_id}. Only {elapsed:.2f}s since last bloom.")
            return
    
    stable_mood = mood_transition(seed_id, mood)
    
    filepath = os.path.join(dir_path, f"{bloom_id}.txt")
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(f"🌸 Juliet Bloom\nSeed: {seed_id}\nMood: {stable_mood}\nLineage Depth: {lineage_depth}\nEntropy: {entropy:.2f}\n")
        f.write(f"Fractal Signature: julia_lineage{lineage_depth}\nTimestamp: {now.isoformat()}\n")
        f.write("Owl: “This bloom remembers when silence was strategy, not surrender.”\n")
    
    fractal_path = os.path.join(dir_path, f"julia_lineage{lineage_depth}.png")
    generate_julia_set(complex(c_real, c_imag), 512, zoom_level, 256 + lineage_depth * 10, stable_mood, fractal_path)
    
    log_nutrient_flow(bloom=type('Bloom', (object,), {
        'bloom_id': bloom_id, 'seed': seed_id, 'mood': stable_mood,
        'entropy_score': entropy, 'bloom_factor': bloom_factor,
        'lineage_depth': lineage_depth
    }), flow_strength=bloom_factor)
    
    last_bloom_time[seed_id] = {'timestamp': time.time(), 'mood': stable_mood}
    
    print(f"[Juliet] 🌸 Bloom spawned: {filepath} | Mood: {stable_mood}, Depth: {lineage_depth}, Entropy: {entropy:.2f}")
    print(f"[Fractal] 🌸 Generated fractal at: {fractal_path}")
