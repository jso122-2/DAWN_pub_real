import numpy as np
import matplotlib.pyplot as plt
import os
import json

FIELD_SIZE = (300, 300)
OUTPUT_DIR = "juliet_flowers/fractal_signatures/"
ROOT = "juliet_flowers/"

# Mood-to-palette mapping
MOOD_CMAP = {
    "calm": "Greens",
    "anxious": "Blues",
    "excited": "Oranges",
    "reflective": "Purples",
    "curious": "viridis"
}

def julia(c, zoom, max_iter):
    x = np.linspace(-1.5, 1.5, FIELD_SIZE[0]) * zoom
    y = np.linspace(-1.5, 1.5, FIELD_SIZE[1]) * zoom
    X, Y = np.meshgrid(x, y)
    Z = X + 1j * Y
    img = np.zeros(Z.shape)

    for i in range(max_iter):
        Z = Z**2 + c
        mask = np.abs(Z) < 10
        img += mask

    return img

def render_fractal(bloom_id, c_real, c_imag, zoom, max_iter, cmap):
    fractal = julia(complex(c_real, c_imag), zoom, max_iter)
    plt.figure(figsize=(4, 4))
    plt.imshow(fractal.T, cmap=cmap, origin="lower")
    plt.axis('off')

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    out_path = os.path.join(OUTPUT_DIR, f"{bloom_id}.png")
    plt.savefig(out_path, bbox_inches='tight', pad_inches=0)
    plt.close()
    print(f"[Fractal] 🌸 Rendered {bloom_id} → {out_path}")

def process_all_blooms():
    for root, _, files in os.walk(ROOT):
        for fname in files:
            if fname.endswith(".json") and "flower" in fname:
                path = os.path.join(root, fname)
                try:
                    with open(path, "r", encoding="utf-8") as f:
                        bloom = json.load(f)
                        bloom_id = bloom["id"]
                        sig = bloom.get("fractal_signature", {})
                        mood = bloom.get("mood", "curious")

                        # Param mapping
                        zoom = 1.5 / (sig.get("bloom_factor", 1.0) + 1)
                        c_real = 0.285 * sig.get("mood_weight", 1.0)
                        c_imag = 0.01 * sig.get("sentence_complexity", 5.0)
                        max_iter = 40 + int(sig.get("seed_density", 1)) * 8
                        cmap = MOOD_CMAP.get(mood, "inferno")

                        render_fractal(bloom_id, c_real, c_imag, zoom, max_iter, cmap)

                except Exception as e:
                    print(f"[WARN] Skipped {fname}: {e}")

if __name__ == "__main__":
    process_all_blooms()
