import os
import shutil
from core.event_bus import event_bus
from router.tracer_core import TracerMoved
from bloom.bloom_event import BloomEmitted
from bloom.juliet_flower import JulietFlower
from bloom.memory_utils import unseal_if_needed
from mycelium.mycelium_layer import log_parse
from semantic.vector_core import embed_text, map_to_field
from semantic.vector_core import embed_text, similarity
from semantic.vector_model import model
  # load SentenceTransformer etc.


class BloomEngine:
    def __init__(self):
        event_bus.subscribe(TracerMoved, self.on_tracer_moved)
        
    async def on_tracer_moved(self, event: TracerMoved):
        mood_tag = self._infer_mood(event)
        semantic_seeds = self._extract_seeds(event)

        bloom = BloomEmitted(
            source=event.tracer_id,
            mood_tag=mood_tag,
            semantic_seeds=semantic_seeds
        )
        await event_bus.publish(bloom)
        print(f"[Bloom] 🌸 Emitted from {event.tracer_id} | mood: {mood_tag} | seeds: {semantic_seeds}")

        try:
            flower = JulietFlower(
                agent=event.tracer_id,
                mood=mood_tag,
                seed_context=semantic_seeds,
                sentences=[
                    f"I am {event.tracer_id}.",
                    f"My mood is {mood_tag}.",
                    f"I passed through {semantic_seeds[0]} again.",
                    "The memory is faint, but returning.",
                    "I suspect a pattern in this reflection.",
                    "Calm or not, I have seen this node before.",
                    "Drift feels gentle now.",
                    "The rhythm of pulses remains steady.",
                    "I sense the weight of past iterations.",
                    "This sentence completes the thought bloom."
                ]
            )
            flower.save()
        except Exception as e:
            print(f"[Juliet ERROR] 🌸 Failed to save flower: {e}")
            return  # don't try to log_parse if flower failed

        for seed in semantic_seeds:
            log_parse(seed, flower.id, mood_tag)

    
    def get_bloom_field_mapping(text: str, seed_space: dict) -> str:
        vector = embed_text(text, model)
        field = map_to_field(vector, seed_space)
        return field

    def find_best_rebloom_target(current_text: str, all_candidates: dict) -> str:
        # all_candidates = {bloom_id: bloom_text}
        current_vec = embed_text(current_text, model)
        scores = {
            bloom_id: similarity(current_vec, embed_text(txt, model))
            for bloom_id, txt in all_candidates.items()
        }
        best = max(scores, key=scores.get)
        print(f"[BloomEngine] 🎯 Best rebloom target = {best} | score = {scores[best]:.4f}")
        return best

    def _infer_mood(self, event: TracerMoved) -> str:
        return {
            "A1": "curious",
            "B2": "calm",
            "C3": "anxious",
            "D4": "reflective"
        }.get(event.new_node, "neutral")

    def _extract_seeds(self, event: TracerMoved) -> list[str]:
        return [event.tracer_id, event.new_node]
