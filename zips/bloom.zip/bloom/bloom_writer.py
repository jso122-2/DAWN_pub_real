import json
import os
from datetime import datetime

REGISTRY_PATH = "bloom_registry.json"

def get_last_ancestor(agent):
    if os.path.exists(REGISTRY_PATH):
        with open(REGISTRY_PATH, "r") as f:
            registry = json.load(f)
            return registry.get(agent)
    return None

def update_registry(agent, bloom_id):
    registry = {}
    if os.path.exists(REGISTRY_PATH):
        with open(REGISTRY_PATH, "r") as f:
            registry = json.load(f)
    registry[agent] = bloom_id
    with open(REGISTRY_PATH, "w") as f:
        json.dump(registry, f, indent=2)

def compute_mood_weight(mood):
    weights = {
        "calm": 0.8,
        "excited": 1.2,
        "anxious": 1.5,
        "curious": 1.1
    }
    return weights.get(mood, 1.0)

def trace_generation_depth(ancestor_id):
    if not ancestor_id:
        return 0
    depth = 0
    current = ancestor_id
    seen = set()
    while current:
        if current in seen:
            break  # prevent loop
        seen.add(current)
        found = False
        for root, _, files in os.walk("juliet_flowers"):
            for fname in files:
                if fname.endswith(".json") and current in fname:
                    with open(os.path.join(root, fname), "r", encoding="utf-8") as f:
                        try:
                            bloom = json.load(f)
                            current = bloom.get("ancestor_id")
                            depth += 1
                            found = True
                            break
                        except:
                            return depth
            if found:
                break
        else:
            break
    return depth

def write_bloom(seed, mood, tick, semantic_pressure, seed_coord, mood_prev=None):
    base_path = f"juliet_flowers/{seed}/{mood}/{tick}"
    os.makedirs(base_path, exist_ok=True)

    timestamp = datetime.now().isoformat().replace(":", "-")
    bloom_id = f"flower-{seed}_{timestamp}"
    path = os.path.join(base_path, f"{bloom_id}.json")

    ancestor = get_last_ancestor(seed)
    generation_depth = trace_generation_depth(ancestor)

    sentences = [
        f"I am {seed}.",
        f"My mood is {mood}.",
        f"I carry {generation_depth} generations behind me.",
        f"Tick: {tick}.",
        f"I feel {mood_prev if mood_prev else mood} still echoing.",
        "The bloom continues."
    ]

    bloom_data = {
        "id": bloom_id,
        "agent": seed,
        "mood": mood,
        "seed_context": [seed],
        "timestamp": timestamp,
        "tick": tick,
        "seed_coord": seed_coord,
        "semantic_pressure": semantic_pressure,
        "mood_prev": mood_prev if mood_prev else mood,
        "sentences": sentences,
        "ancestor_id": ancestor,
        "fractal_signature": {
            "mood_weight": compute_mood_weight(mood),
            "seed_density": generation_depth + 1,
            "sentence_complexity": len(" ".join(sentences)) / 10.0,
            "bloom_factor": round((generation_depth + 1) * semantic_pressure, 3)
        }
    }

    heat = mood_to_heat(mood)
    pulse.add_heat(heat)

def mood_to_heat(mood):
    mapping = {
        "anxious": 0.3,
        "excited": 0.2,
        "curious": 0.1,
        "reflective": 0.05,
        "calm": -0.2
    }
    raw = mapping.get(mood.lower(), 0.0)
    clamped = max(-0.3, min(raw, 0.3))  # 🔒 clamp range [-0.3, +0.3]
    return clamped



    with open(path, "w", encoding="utf-8") as f:
        json.dump(bloom_data, f, indent=2)

    update_registry(seed, bloom_id)
    print(f"[Bloom] 🌸 Emitted from {seed} | mood: {mood} | gen: {generation_depth} | ancestor: {ancestor} | path: {path}")
