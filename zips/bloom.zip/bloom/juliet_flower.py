import os
import json
from datetime import datetime

JULIET_DIR = "juliet_flowers"
os.makedirs(JULIET_DIR, exist_ok=True)

class JulietFlower:
        def __init__(self, agent: str, mood: str, seed_context: list[str], sentences: list[str], ancestor_id: str = None):
            now = datetime.utcnow().isoformat().replace(":", "-")
            self.id = f"flower-{agent}_{now}"
            self.agent = agent
            self.mood = mood
            self.seed_context = seed_context
            self.sentences = sentences
            self.ancestor_id = ancestor_id  # 🧬 lineage tracking
            self.timestamp = datetime.utcnow().isoformat()
                    
        def generate_fractal_signature(self) -> dict:
            mood_weights = {
                "calm": 1.0,
                "curious": 1.2,
                "reflective": 1.4,
                "anxious": 1.6,
                "overload": 1.8
            }

            weight = mood_weights.get(self.mood, 1.0)
            complexity = len(set(" ".join(self.sentences).split())) / len(self.sentences)

            recursive_modifier = 1.0
            if self.ancestor_id:
                recursive_modifier = 1.15  # amplify bloom factor over generations

            return {
                "mood_weight": weight,
                "seed_density": len(self.seed_context),
                "sentence_complexity": round(complexity, 2),
                "bloom_factor": round(weight * complexity * len(self.seed_context) * recursive_modifier, 3)
            }


        def to_dict(self):
            return {
                "id": self.id,
                "agent": self.agent,
                "mood": self.mood,
                "seed_context": self.seed_context,
                "sentences": self.sentences,
                "timestamp": self.timestamp,
                "ancestor_id": self.ancestor_id,
                "fractal_signature": self.generate_fractal_signature()
            }


        def save(self):
            for seed in self.seed_context:
                dir_path = os.path.join(JULIET_DIR, seed, self.mood)
                os.makedirs(dir_path, exist_ok=True)
                file_path = os.path.join(dir_path, f"{self.id}.json")


